#include<iostream>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
int py[100000009];
int pynum[100000009];
int numy[100000009];
int a[1000000];
int main(){
	ios::sync_with_stdio(false); 
	int n,p;
	cin>>n>>p;
	int cp=p;
	int num=0;
	for(int i=2;i<=p;i++){
		bool f=false;
		while(cp%i==0){
			py[num]=i;
			pynum[num]++;
			cp/=i;
			f=true;
		}
		if(f)num++;
	}
	for(int i=0;i<num;i++){
		unsigned long long cac=1;
		while(cac*py[i]<=n){
			cac*=py[i];
			numy[i]+=n/cac;
		}
	}
	int ans=0x3f3f3f3f;
	for(int i=0;i<num;i++){
		ans=min(ans,numy[i]/pynum[i]);
	}
	cout<<ans;
	return 0;
}
