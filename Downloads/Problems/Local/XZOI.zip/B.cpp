#include<iostream>
#include<cstring>
#include<string>
using namespace std;
int main(){
	ios::sync_with_stdio(false); 
	string s;
	cin>>s;
	bool if_m=false;
	if(s[0]=='-')cout<<"-";
	bool if_st=false;
	for(int i=s.length()-1;i>=0;i--){
		if(s[i]!='0' && ~if_st)if_st=true;
		if(if_st && s[i]!='-')cout<<s[i];
	}
	return 0;
}
