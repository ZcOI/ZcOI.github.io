#include<iostream>
using namespace std;
long dp[10000009];
int main(){
	ios::sync_with_stdio(false); 
	int n;
	cin>>n;
	if(n==1){cout<<0;return 0;}
	dp[0]=0;
	dp[1]=0;
	dp[2]=2;
	dp[3]=1;
	//int ans=0;
	for(int i=4;i<=n+3;i+=3){
		dp[i]=dp[i-1]+1;
		dp[i+2]=dp[(i+2)/3]+1;
		dp[i+1]=dp[i+2]+1;
	}
	unsigned long long ans=0;
	for(int i=1;i<=n;i++)ans+=dp[i];
	cout<<ans;
	return 0;
}
