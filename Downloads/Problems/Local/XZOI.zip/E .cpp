#include<iostream>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
int py[100000009];
int pynum[100000009];
int numy[100000009];
int a[1000000];
int main(){
	ios::sync_with_stdio(false); 
	int n,p;
	cin>>n>>p;
	int cp=p;
	int num=0;
	for(int i=2;i<=p;i++){
		bool f=false;
		while(cp%i==0){
			py[num]=i;
			pynum[num]++;
			cp/=i;
			f=true;
		}
		if(f)num++;
	}
	for(int i=0;i<num;i++){
		memset(a,0,sizeof(a));
		int nn=0;
		a[py[i]]=1;
		for(int j=1;j*py[i]<=n;j++){
			a[j*py[i]]=1+a[j];
			nn+=a[j*py[i]];
		}
		numy[i]=nn;
	}
	int ans=0x3f3f3f3f;
	for(int i=0;i<num;i++){
		ans=min(ans,numy[i]/pynum[i]);
	}
	cout<<ans;
	return 0;
}
