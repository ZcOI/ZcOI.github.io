#include<iostream>
using namespace std;
int main(){
	ios::sync_with_stdio(false); 
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		int a,b;
		int ans;
		char c;
		cin>>a>>b>>c;
		if(c=='+')ans=a+b;
		else if(c=='-')ans=a-b;
		else if(c=='*')ans=a*b;
		else ans=a/b;
		cout<<a<<c<<b<<"="<<ans<<"\n";
	}
	return 0;
}
